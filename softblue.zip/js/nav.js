const showMenuLinks = () => {
  document.getElementById('menuNav').classList.toggle('show');
  document.getElementById('hamburgerMenu').classList.toggle('show');
  console.log('showMenuLinks loaded -nav');
};
